#! /bin/bash
cd /home/ctf && ./challenge
