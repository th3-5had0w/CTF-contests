#!/bin/sh
#

/home/rock_paper_scissors/rock_paper_scissors > /dev/nulll
