See the github page for instructions on how to run and use the game.
https://github.com/Drewol/unnamed-sdvx-clone

Licenses:

------------------
unnamed-sdvx-clone
------------------
Copyright 2016-2018 Guus Waals (guus_waals@live.nl)
Copyright 2016-2019 Emil Draws (https://github.com/Drewol)

-------------
THIRD PARTIES
-------------

FreeType - Copyright (c) 2006-2015 David Turner, Robert Wilhelm, and Werner Lemberg

IJG JPEG - copyright (C) 1991-2016, Thomas G. Lane, Guido Vollbeding

libogg - Copyright (c) 2002, Xiph.org Foundation

libvorbis - Copyright (c) 2002-2015 Xiph.org Foundation

libpng - Copyright (c) 2000-2002, 2004, 2006-2016 Glenn Randers-Pehrson

Lua - Copyright (c) 1994?2017 Lua.org, PUC-Rio.

nanovg - Copyright (c) 2013 Mikko Mononen memon@inside.org

nuklear - Copyright (c) 2017 Micha Mettke

Simple DirectMedia Layer - Copyright (c) 1997-2016 Sam Lantinga <slouken@libsdl.org>

zlib - (c) 1995-2013 Jean-loup Gailly and Mark Adler

cpr - Copyright (c) 2017 Huu Nguyen

curl - Copyright (c) 1996 - 2017, Daniel Stenberg, <daniel@haxx.se>

miniaudio - Copyright (c) 2019 David Reid

JSON for Modern C++ - Copyright (c) 2013-2019 Niels Lohmann

libiconv - Copyright (C) 1998, 2019 Free Software Foundation, Inc.


THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE 
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
DEALINGS IN THE SOFTWARE.
