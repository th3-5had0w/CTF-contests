#!/bin/sh
#

# service xinetd restart && sleep infinity
/home/rock_paper_scissors/run.sh && sleep infinity
